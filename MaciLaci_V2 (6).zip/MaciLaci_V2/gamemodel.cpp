    #include "gamemodel.h"
#include <QFile>
#include <QTextStream>
#include <QStringList>
#include <QString>
#include <QDebug>

CgameModel::CgameModel()
{

}
void CgameModel::Read(int size)
{
    m_barriers.clear();
    m_baskets.clear();
    m_guards.clear();
    m_ML.setCollectedBasketsToZero();
    m_paused = false;
    m_lost = false;
    m_won = false;
    QString fileName;
    switch(size)
    {
        case 5:
        {
            fileName = ":/5/5x5.txt";
            break;
        }
         case 7:
        {
            fileName = ":/7/7x7.txt";
            break;
        }
        case 10:
        {
            fileName = ":/10/10x10.txt";
            break;
        }
        default:
            return;
    }
    m_boardSize = size;
    QFile inputFile(fileName);
    if(!inputFile.open(QIODevice::ReadOnly | QIODevice::Text)){qInfo()<<"false";return;}
    QTextStream in(&inputFile);
    for(int i = 0; i < size; i++)
        {
            QString line = in.readLine();
            QStringList lineParts;
            lineParts = line.split(QRegExp("\\s"));
            for(int j = 0; j < size;j++)
            {
                if(lineParts.at(j).toInt() == 1)
                {
                    m_ML.setPosition(i,j);
                }
                else if(lineParts.at(j).toInt() == 2)
                {
                    m_barriers.push_back(CScreenObject(i,j));
                }
                else if(lineParts.at(j).toInt() == 3)
                {
                    m_guards.push_back(CGuard(i,j, Left));
                }
                else if(lineParts.at(j).toInt() == 4)
                {
                    m_guards.push_back(CGuard(i,j, Up));
                }
                else if(lineParts.at(j).toInt() == 5)
                {
                    m_baskets.push_back(CScreenObject(i,j));
                }
            }
        }
}
bool CGuard::IsObjectSeen(const CScreenObject & other) const
{
    return abs(m_x-other.X()) <= 1 && abs(m_y-other.Y()) <= 1;
}
void CScreenObject::Move(Direction direction,int &newX, int &newY) const
{
    switch(direction)
    {
        case Left:
        {
            newX = X();
            newY = Y()-1;
            break;
        }
        case Right:
        {
            newX = X();
            newY = Y()+1;
            break;
        }
        case Up:
        {
            newX = X()-1;
            newY = Y();
            break;
        }
        case Down:
        {
            newX = X()+1;
            newY = Y();
            break;
        }
    }
}
void CML::Move(Direction direction, const CScreenObjects &barriers, const CGuards &guards, int boardSize, CScreenObjects &baskets)
{
    int newX;
    int newY;
    CScreenObject::Move(direction, newX, newY);
    bool isAbleToMove = true;
    if(newX >= boardSize || newY >= boardSize || newX < 0 || newY < 0)
    {
       isAbleToMove = false;
    }
    for(unsigned int i = 0; i < barriers.size() && isAbleToMove; i++)
    {
        if(newX == barriers[i].X() && newY == barriers[i].Y())
        {
            isAbleToMove = false;
        }
    }
    for(unsigned int i = 0; i < guards.size() && !isAbleToMove; i++)
    {
        if(newX == guards[i].X() && newY == guards[i].Y())
        {
            isAbleToMove = false;
        }
    }
    if(isAbleToMove)
    {
        m_x = newX;
        m_y = newY;
        for(CScreenObjects::iterator it = baskets.begin(); it != baskets.end();)
        {
            if(m_x == it->X() && m_y == it->Y())
            {
                it = baskets.erase(it);
                m_numberOfCollectedBaskets++;
                break;
            }
            else
            {
                it++;
            }
        }
    }
}
void CGuard::Move (const CScreenObjects &barriers, const CGuards &guards, int boardSize, bool secondAttempt)
{
    int newX;
    int newY;
    CScreenObject::Move(m_movingDirection, newX, newY);
    bool changedDirection = false;
    //Ha kiakarnánk lépni
    if(newX >= boardSize || newY >= boardSize || newX < 0 || newY < 0)
    {
       changedDirection = true;
    }
    //Akadályokra akarnánk lépni
    for(unsigned int i = 0; i < barriers.size() && !changedDirection; i++)
    {
        if(newX == barriers[i].X() && newY == barriers[i].Y())
        {
            changedDirection = true;
        }
    }
    for(unsigned int i = 0; i < guards.size() && !changedDirection; i++)
    {
        if(newX == guards[i].X() && newY == guards[i].Y())
        {
            changedDirection = true;
        }
    }

    if(changedDirection)
    {
        if(secondAttempt)
        {
            return;
        }
        else
        {
            switch(m_movingDirection)
            {
                case Left:
                {
                    m_movingDirection = Right;
                    break;
                }
                case Right:
                {
                    m_movingDirection = Left;
                    break;
                }
                case Up:
                {
                    m_movingDirection = Down;
                    break;
                }
                case Down:
                {
                    m_movingDirection = Up;
                    break;
                }
            }
            Move(barriers, guards, boardSize, true);
        }
    }
    else
    {
        m_x = newX;
        m_y = newY;
    }
}
void CgameModel::OnMoveGuards()
{
    if(m_paused || m_won || m_lost)
    {
        return;
    }
    for(unsigned int i = 0; i < m_guards.size(); i++)
    {
        m_guards[i].Move(m_barriers, m_guards, m_boardSize, false);
        if(m_guards[i].IsObjectSeen(m_ML))
        {
            m_lost = true;
            gameLost();
            return;
        }
    }
}
void CgameModel::OnKey(Direction direction)
{
    if(m_paused || m_won || m_lost)
    {
        return;
    }
    m_ML.Move(direction, m_barriers, m_guards, m_boardSize, m_baskets);
    if(m_baskets.size() == 0)
    {
        m_won = true;
        gameWon();
        return;
    }
    for(unsigned int i = 0; i < m_guards.size(); i++)
    {
        if(m_guards[i].IsObjectSeen(m_ML))
        {
            m_lost = true;
            gameLost();
            return;
        }
    }
}
