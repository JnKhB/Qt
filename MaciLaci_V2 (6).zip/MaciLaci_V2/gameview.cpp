#include "gameview.h"
#include <QFile>
#include <QTextStream>
#include <QKeyEvent>
#include <QDebug>
#include <QRandomGenerator>
#include <QLCDNumber>
#include <QMessageBox>

CgameView::CgameView(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle(tr("Maci Laci játék"));
    setMinimumSize(400,400);
    m_gridLayout = new QGridLayout();
    m_buttonsLayout = new QHBoxLayout();
    m_mainLayout = new QVBoxLayout();
    m_startNewGameBtn1 = new QPushButton(this);
    m_startNewGameBtn1->setText("Start 5x5");
    m_startNewGameBtn1->setMinimumSize(80,30);
    m_buttonsLayout->addWidget(m_startNewGameBtn1);

    m_startNewGameBtn2 = new QPushButton(this);
    m_startNewGameBtn2->setText("Start 7x7");
    m_startNewGameBtn2->setMinimumSize(80,30);
    m_buttonsLayout->addWidget(m_startNewGameBtn2);

    m_startNewGameBtn3 = new QPushButton(this);
    m_startNewGameBtn3->setText("Start 10x10");
    m_startNewGameBtn3->setMinimumSize(80,30);
    m_buttonsLayout->addWidget(m_startNewGameBtn3);

    connect(m_startNewGameBtn1, SIGNAL(clicked()), this, SLOT(startNewGame1()));
    connect(m_startNewGameBtn2, SIGNAL(clicked()), this, SLOT(startNewGame2()));
    connect(m_startNewGameBtn3, SIGNAL(clicked()), this, SLOT(startNewGame3()));
    m_model = new CgameModel();

    m_timer = new QTimer(this);
    m_timer2 = new QTimer(this);
    connect(m_timer, SIGNAL(timeout()), this, SLOT(updateStatusBar()));
    connect(m_timer, SIGNAL(timeout()), this, SLOT(policeMoving()));
    connect(m_timer2, SIGNAL(timeout()), this, SLOT(addingTime()));

    m_showTimeAndPoints = new QStatusBar();
    m_showTimeAndPoints->showMessage("Pontok: " + QString::number(m_model->getCollectedBaskets())
    + " | Eltelt idő: "+QString::number(m_timeOfTime2)+" mp");

    m_pauseButton = new QPushButton();
    m_pauseButton->setText("Játék szüneteltetése");
    m_pauseButton->setEnabled(false);
    m_pauseButton->setMaximumSize(130,30);

    m_mainLayout->addLayout(m_buttonsLayout);
    m_mainLayout->addWidget(m_showTimeAndPoints);
    m_mainLayout->addWidget(m_pauseButton);
    setLayout(m_mainLayout);

    connect(m_pauseButton, SIGNAL(clicked()), this, SLOT(clickOnPauseOrResume()));
    connect(m_model, SIGNAL(gameWon()), this, SLOT(model_gameWon()));
    connect(m_model, SIGNAL(gameLost()), this, SLOT(model_gameOver()));

    m_boardView = 0;

    this->grabKeyboard();
}

CgameView::~CgameView()
{
    if(m_boardView != 0)
    {
        for(int i = 0; i < m_model->getBoardSize(); i++)
        {
            delete m_boardView[i];
        }
        delete m_boardView;
    }
    for(int i = 0; i < m_labelVector.length();i++)
    {
        m_gridLayout->removeWidget(m_labelVector.at(i));
        delete m_labelVector.at(i);
    }
    m_labelVector.clear();
}
void CgameView::startNewGame1()
{
    int size = 5;
    setMinimumSize(700,700);
    startWithDifferentSize(size);
}
void CgameView::startNewGame2()
{
    int size = 7;
    setMinimumSize(800,800);
    startWithDifferentSize(size);
}
void CgameView::startNewGame3()
{
    int size = 10;
    setMinimumSize(800,800);
    startWithDifferentSize(size);
}
void CgameView::keyPressEvent(QKeyEvent* event)
{
    Direction direction;
        switch(event->key())
        {
            case Qt::Key_Right:
            {
                direction = Right;
                break;
            }
            case Qt::Key_Left:
            {
                direction = Left;
                break;
            }
            case Qt::Key_Up:
            {
                direction = Up;
                break;
            }
            case Qt::Key_Down:
            {
                direction = Down;
                break;
            }
            default:
                return;
        }
        m_model->OnKey(direction);
        redrawBoard();
        updateStatusBar();
}
void CgameView::updateStatusBar()
{
     m_showTimeAndPoints->showMessage("Pontok: " + QString::number(m_model->getCollectedBaskets())
     +" | Eltelt idő: "+QString::number(m_timeOfTime2)+" mp");
}
void CgameView::redrawBoard()
{
    for(int i = 0; i < m_labelVector.length();i++)
    {
        m_gridLayout->removeWidget(m_labelVector.at(i));
        delete m_labelVector.at(i);
    }
    m_labelVector.clear();
    for(int i = 0; i < m_model->getBoardSize(); i++)
    {
        for(int j = 0; j < m_model->getBoardSize(); j++)
        {
                    m_boardView[i][j] = 0;
        }
    }
    for(int i = 0; i < m_model->getBarriers().size(); i++)
    {
        m_boardView[m_model->getBarriers()[i].X()][m_model->getBarriers()[i].Y()] = 2;
    }
    for(int i = 0; i < m_model->getBaskets().size(); i++)
    {
        m_boardView[m_model->getBaskets()[i].X()][m_model->getBaskets()[i].Y()] = 5;
    }
    for(int i = 0; i < m_model->getGuards().size(); i++)
    {
        m_boardView[m_model->getGuards()[i].X()][m_model->getGuards()[i].Y()] = 3;
    }
    m_boardView[m_model->getML().X()][m_model->getML().Y()] = 1;
    for(int i = 0; i < m_model->getBoardSize(); i++)
    {
        for(int j = 0; j < m_model->getBoardSize();j++)
        {
            QLabel* label = new QLabel(QString::number(m_boardView[i][j]), this);
            if(m_boardView[i][j] == 0)
            {
                QPixmap* m_pixmap = new QPixmap("../MaciLaci_V2/fu.png");
                label->setPixmap(m_pixmap->scaled(50, 50));
            }
            else if(m_boardView[i][j] == 1)
            {
                QPixmap* m_pixmap = new QPixmap("../MaciLaci_V2/macilaci.png");
                label->setPixmap(m_pixmap->scaled(50, 50));
            }
            else if(m_boardView[i][j] == 2)
            {
                QPixmap* m_pixmap = new QPixmap("../MaciLaci_V2/fa.png");
                label->setPixmap(m_pixmap->scaled(50, 50));
            }
            else if(m_boardView[i][j] == 3)
            {
                QPixmap* m_pixmap = new QPixmap("../MaciLaci_V2/or.png");
                label->setPixmap(m_pixmap->scaled(50, 50));
            }
            else if(m_boardView[i][j] == 5)
            {
                QPixmap* m_pixmap = new QPixmap("../MaciLaci_V2/kosar.png");
                label->setPixmap(m_pixmap->scaled(50, 50));
            }
            m_gridLayout->addWidget(label, i, j);
            m_labelVector.push_back(label);
        }
    }
    m_mainLayout->addLayout(m_gridLayout);
}
void CgameView::policeMoving()
{
    m_model->OnMoveGuards();
    redrawBoard();
}
void CgameView::model_gameWon()
{
    QMessageBox msgBox;
    msgBox.setText("Játék vége! Ön nyert!");
    msgBox.exec();
    m_timer->stop();
    m_timer2->stop();
}
void CgameView::model_gameOver()
{
    QMessageBox msgBox;
    msgBox.setText("Játék vége! Ön vesztett!");
    msgBox.exec();
    m_timer->stop();
    m_timer2->stop();
}
void CgameView::clickOnPauseOrResume()
{
    if(m_model->isPaused())
    {
       m_timer2->start();
       m_model->Resume();
       m_pauseButton->setText("Játék szüneteltetése");
    }
    else
    {
        m_timer2->stop();
        m_model->Pause();
        m_pauseButton->setText("Játék folytatása");
    }
}
void CgameView::addingTime()
{
    m_timeOfTime2++;
    updateStatusBar();
}
void CgameView::startWithDifferentSize(int size)
{

    if(m_boardView != 0)
    {
        for(int i = 0; i < m_model->getBoardSize(); i++)
        {
            delete m_boardView[i];
        }
        delete m_boardView;
    }
    m_pauseButton->setEnabled(true);
    m_timeOfTime2 = 0;
    m_timer->start(1000);
    m_timer2->start(1000);
    m_boardView = new int*[size];
    for(int i = 0; i< size; i++)
    {
        m_boardView[i] = new int[size];
    }
    m_model->Read(size);
    redrawBoard();
}
