#ifndef GAMEMODEL_H
#define GAMEMODEL_H


#include <QObject>
enum Direction { Left, Right, Up, Down };
class CScreenObject
{
 public:
    CScreenObject (int x = 0, int y = 0) : m_x (x), m_y (y) {}
    int X () const { return m_x ; }
    int Y () const { return m_y ; }
    void setPosition(int x, int y){m_x = x; m_y = y;};
    void Move(Direction direction,int &newX, int &newY) const;
 protected:
    int m_x ;
    int m_y ;
};
class CGuard;
typedef std::vector<CGuard> CGuards;
typedef std::vector<CScreenObject> CScreenObjects ;

class CGuard : public CScreenObject
 {
 public:
    CGuard (int x = 0, int y = 0, Direction direction = Left) : CScreenObject (x, y), m_movingDirection (direction) {}
    bool IsObjectSeen (const CScreenObject & other) const ;
    void Move (const CScreenObjects &barriers, const CGuards &guards, int boardSize, bool secondAttempt = false);


 protected:
    Direction m_movingDirection ;
 } ;


class CML : public CScreenObject
 {
 public:
    void Move (Direction direction, const CScreenObjects &barriers, const CGuards &guards, int boardSize, CScreenObjects &baskets);
    int getNumberOfCollectedBakets() const {return m_numberOfCollectedBaskets;};
    void setCollectedBasketsToZero() {m_numberOfCollectedBaskets = 0; };

 private:
    int m_numberOfCollectedBaskets = 0;
 } ;

class CgameModel : public QObject
{
    Q_OBJECT
public:
    CgameModel();
    void Read(int size) ;
    void Pause() {m_paused = true;};
    void Resume() {m_paused = false;};
    void OnMoveGuards() ;
    void OnKey(Direction direction) ;
    size_t getSizeOfBaskets() { return m_baskets.size(); };
    bool isPaused() {return m_paused;};
    const CScreenObjects &getBaskets() const {return m_baskets;};
    const CScreenObjects &getBarriers() const {return m_barriers;};
    const CML &getML() const {return m_ML;};
    const CGuards &getGuards() const {return m_guards;};
    int getBoardSize() const {return m_boardSize;};
    bool Won () {return m_won; };
    bool Lost () {return m_lost; };
    int getCollectedBaskets() {return m_ML.getNumberOfCollectedBakets();};
signals:
    void gameWon();
    void gameLost();
protected:
    CScreenObjects m_baskets ;
    CScreenObjects m_barriers ;
    CGuards m_guards ;
    CML	m_ML ;
    bool m_paused = false;
    int m_boardSize;
    bool m_lost = false;
    bool m_won = false;
} ;

#endif // GAMEMODEL_H
