#ifndef GAMEVIEW_H
#define GAMEVIEW_H
#include "gamemodel.h"
#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QVector>
#include <QGridLayout>
#include <QKeyEvent>
#include <QTimer>
#include <QLCDNumber>
#include <QStatusBar>

class CgameView : public QWidget
{
    Q_OBJECT
public:
    CgameView(QWidget *parent = nullptr);
    ~CgameView();
     void keyPressEvent(QKeyEvent* event);
     void redrawBoard();
     void startWithDifferentSize(int size);

private slots:
    void startNewGame1();
    void startNewGame2();
    void startNewGame3();
    void updateStatusBar();
    void policeMoving();
    void model_gameOver();
    void model_gameWon();
    void clickOnPauseOrResume();
    void addingTime();
private:
    QPushButton* m_startNewGameBtn1;
    QPushButton* m_startNewGameBtn2;
    QPushButton* m_startNewGameBtn3;
    QPushButton* m_pauseButton;
    QLabel* m_label;
    QGridLayout* m_gridLayout;

    QHBoxLayout* m_buttonsLayout;
    QVBoxLayout* m_mainLayout;
    CgameModel* m_model;
    QVector<QLabel*> m_labelVector;
    QTimer* m_timer;
    QTimer* m_timer2;
    QPixmap* m_pixmap;
    QStatusBar* m_showTimeAndPoints;
    int** m_boardView;
    int boardSize;
    int m_timeOfTime2 = 0;
};
#endif // GAMEVIEW_H
